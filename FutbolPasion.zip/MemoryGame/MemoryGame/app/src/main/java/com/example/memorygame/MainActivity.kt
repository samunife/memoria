package com.example.memorygame

import db.juegodememoria.PlayerDatabaseHelper
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import android.content.ContentValues



class MainActivity : AppCompatActivity() {

    private lateinit var gridLayout: GridLayout
    private val imageViews = mutableListOf<ImageView>()
    private var score = 0
    private lateinit var dbHelper: PlayerDatabaseHelper
    private var selectedCard: ImageView? = null
    private var selectedImageRes: Int? = null
    private lateinit var timer: CountDownTimer
    private var timeLeftInMillis: Long = 120000 // 2 minutos en milisegundos
    private var matchedPairs = 0
    private var isGameFinished = false


    // Lista de recursos de imagen, con 8 imágenes únicas, cada una aparecerá dos veces en el juego
    private val imageResources = listOf(
        R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4,
        R.drawable.image5, R.drawable.image6, R.drawable.image7, R.drawable.image8
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Suponiendo que PlayerDatabaseHelper es una clase que ya has creado
        dbHelper = PlayerDatabaseHelper(this)

        gridLayout = findViewById(R.id.gridLayout)
        setupGameBoard()

        val btnReset = findViewById<Button>(R.id.btnReset)
        btnReset.setOnClickListener {
            resetGame()
        }

        val btnExit = findViewById<Button>(R.id.btnExit)
        btnExit.setOnClickListener {
            finish()
        }

        // Inicia el temporizador al principio del juego
        startTimer()
    }

    private fun setupGameBoard() {
        // Elimina las imágenes existentes antes de agregar nuevas imágenes
        gridLayout.removeAllViews()

        // Preparar el tablero de juego con imágenes aleatorias
        val images = imageResources.shuffled().take(8) + imageResources.shuffled().take(8)
        images.shuffled().forEach { imageRes ->
            val imageView = ImageView(this)
            imageView.layoutParams = GridLayout.LayoutParams().apply {
                height = 150 // o cualquier tamaño que desees
                width = 150
                rightMargin = 8
                topMargin = 8
                bottomMargin = 8
                leftMargin = 8
            }
            imageView.setBackgroundResource(R.drawable.image1)
            imageView.setOnClickListener {
                onCardClicked(imageView, imageRes)
            }
            gridLayout.addView(imageView)
            imageViews.add(imageView)
        }
    }

    private fun onCardClicked(imageView: ImageView, imageRes: Int) {
        imageView.setImageResource(imageRes)

        if (selectedCard == null) {
            selectedCard = imageView
            selectedImageRes = imageRes
        } else {
            if (selectedImageRes == imageRes && selectedCard != imageView) {
                // Coincidencia encontrada
                playMatchSound()
                score += 10
                updateScoreDisplay()
                selectedCard!!.isEnabled = false
                imageView.isEnabled = false
                selectedCard = null
                selectedImageRes = null
                matchedPairs++

                // Verificar si todas las parejas han sido acertadas
                if (matchedPairs == 8) {
                    onGameFinished()
                }
            } else {
                Handler(Looper.getMainLooper()).postDelayed({
                    imageView.setImageResource(R.drawable.image1)
                    selectedCard?.setImageResource(R.drawable.image1)
                    selectedCard = null
                    selectedImageRes = null
                    score -= 5
                    updateScoreDisplay()
                }, 1000)
            }
        }
    }

    private fun playMatchSound() {
        // Aquí debes implementar la reproducción del sonido de coincidencia
    }

    private fun resetGame() {
        // Restablecer el juego a su estado inicial
        score = 0
        updateScoreDisplay()
        selectedCard = null
        selectedImageRes = null
        imageViews.forEach {
            it.setImageResource(R.drawable.image1)
            it.isEnabled = true
        }
        setupGameBoard()
        timer.cancel()
        timeLeftInMillis = 120000
        startTimer()
    }
    private fun onGameFinished() {
        isGameFinished = true // Marcar el juego como finalizado
        imageViews.forEach { it.isEnabled = false }
        Toast.makeText(this, "Has finalizado! Tu puntuación es: $score", Toast.LENGTH_LONG).show()
        // Aquí podrías guardar la puntuación en la base de datos si lo deseas

        // Detener el contador de segundos
        timer.cancel()
    }
    private fun startTimer() {
        timer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                if (!isGameFinished) { // Verificar si el juego no ha finalizado
                    timeLeftInMillis = millisUntilFinished
                    updateCountDownText()
                }
            }

            override fun onFinish() {
                if (!isGameFinished) { // Verificar si el juego no ha finalizado
                    onGameOver()
                }
            }
        }.start()
    }

    private fun updateCountDownText() {
        val minutes = (timeLeftInMillis / 1000) / 60
        val seconds = (timeLeftInMillis / 1000) % 60
        val timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
        findViewById<TextView>(R.id.tvTimer).text = timeFormatted
    }

    private fun updateScoreDisplay() {
        findViewById<TextView>(R.id.tvScore).text = "Score: $score"
    }

    private fun onGameOver() {
        imageViews.forEach { it.isEnabled = false }
        Toast.makeText(this, "Game Over! Your score is: $score", Toast.LENGTH_LONG).show()
        // Aquí podrías guardar la puntuación en la base de datos si lo deseas
    }
}

