package db.juegodememoria

import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PlayerDatabaseHelper(
    context: Context
) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "memorygame.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_PLAYERS = "players"
        private const val COLUMN_PLAYER_NAME = "name"
        private const val COLUMN_PLAYER_SCORE = "score"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableStatement = """
            CREATE TABLE $TABLE_PLAYERS (
                $COLUMN_PLAYER_NAME TEXT PRIMARY KEY,
                $COLUMN_PLAYER_SCORE INTEGER
            )
        """.trimIndent()

        db.execSQL(createTableStatement)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Aquí manejas las actualizaciones de la base de datos si cambias DATABASE_VERSION
    }

    fun savePlayerScore(playerName: String, score: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_PLAYER_NAME, playerName)
            put(COLUMN_PLAYER_SCORE, score)
        }

        var success = false
        try {
            // Try to insert the player's score into the database.
            // If the player already exists, this will fail.
            success = db.insert(TABLE_PLAYERS, null, values) != -1L
        } catch (e: Exception) {
            // Handle the exception, possibly log it, or rethrow it.
            e.printStackTrace()
        } finally {
            // Make sure to close the database when done.
            db.close()
        }

        return success
        }
        fun savePlayerName(playerName: String) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put("player_name", playerName)

        // Insertar el nombre del jugador en la tabla de jugadores
        db.insert("players", null, values)
        db.close()
         }
    // Aquí podrías agregar más métodos para consultar o actualizar la base de datos según lo necesites.
}
