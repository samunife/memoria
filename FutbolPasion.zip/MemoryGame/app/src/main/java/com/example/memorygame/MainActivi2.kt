package com.example.memorygame

import db.juegodememoria.DatabaseHandler
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import android.content.ContentValues
import android.media.MediaPlayer
import org.w3c.dom.Text


class MainActivi2 : AppCompatActivity() {

    private lateinit var gridLayout: GridLayout
    private val imageViews = mutableListOf<ImageView>()
    private var score = 0
    private var selectedCard: ImageView? = null
    private var selectedImageRes: Int? = null
    private lateinit var timer: CountDownTimer
    private var timeLeftInMillis: Long = 60000



    private val imageResources = listOf(
        R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4,
        R.drawable.image5, R.drawable.image6, R.drawable.image7, R.drawable.image8
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        val playerName = intent.getStringExtra("PLAYER_NAME")
        val lastScore = intent.getIntExtra("LAST_SCORE", 0)
        val playerNameTextView = findViewById<TextView>(R.id.tvPlayerName)
        val playerScoreTextView = findViewById<TextView>(R.id.tvLastScore)

        playerNameTextView.text = "Player: $playerName"
        playerScoreTextView.text = "Last Score: $lastScore"


        gridLayout = findViewById(R.id.gridLayout)
        setupGameBoard()

        val btnReset = findViewById<Button>(R.id.btnReset)
        btnReset.setOnClickListener {
            resetGame()
        }

        val btnExit = findViewById<Button>(R.id.btnExit)
        btnExit.setOnClickListener {
            finish()
        }


        startTimer()
    }

    private fun setupGameBoard() {

        gridLayout.removeAllViews()

        val images = imageResources.shuffled().take(8) + imageResources.shuffled().take(8)
        images.shuffled().forEach { imageRes ->
            val imageView = ImageView(this)
            imageView.layoutParams = GridLayout.LayoutParams().apply {
                height = 220
                width = 220
                rightMargin = 8
                topMargin = 8
                bottomMargin = 8
                leftMargin = 8
            }
            imageView.setBackgroundResource(R.drawable.imagen9)
            imageView.setOnClickListener {
                onCardClicked(imageView, imageRes)
            }
            gridLayout.addView(imageView)
            imageViews.add(imageView)
        }
    }

    private fun onCardClicked(imageView: ImageView, imageRes: Int) {
        imageView.setImageResource(imageRes)

        if (selectedCard == null) {
            selectedCard = imageView
            selectedImageRes = imageRes
        } else {
            if (selectedImageRes == imageRes && selectedCard != imageView) {
                // Coincidencia encontrada
                when (imageRes) {
                    R.drawable.image1 -> playSpecialSound1()
                    R.drawable.image2 -> playSpecialSound2()
                    R.drawable.image3 -> playSpecialSound3()
                    R.drawable.image4 -> playSpecialSound4()
                    R.drawable.image5 -> playSpecialSound5()
                    R.drawable.image6 -> playSpecialSound6()
                    R.drawable.image7 -> playSpecialSound7()
                    R.drawable.image8 -> playSpecialSound8()
                    else -> playMatchSound()
                }
                score += 100
                updateScoreDisplay()
                selectedCard!!.isEnabled = false
                imageView.isEnabled = false
                selectedCard = null
                selectedImageRes = null

                if (allCardsMatched()) {
                    onGameWon()
                }
            } else {
                Handler(Looper.getMainLooper()).postDelayed({
                    imageView.setImageResource(R.drawable.imagen9)
                    selectedCard?.setImageResource(R.drawable.imagen9)
                    selectedCard = null
                    selectedImageRes = null

                    // Asegurar que el puntaje no sea negativo
                    if (score > 0) {
                        score -= 50
                    }
                    updateScoreDisplay()


                        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_error)
                        mediaPlayer.start()

                }, 500)
            }
        }
    }
    private fun playSpecialSound1() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_especial1) // Reemplaza "sonido_especial" con el nombre correcto de tu archivo de sonido
        mediaPlayer.start()
    }
    private fun playSpecialSound2() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_especial2) // Reemplaza "sonido_especial" con el nombre correcto de tu archivo de sonido
        mediaPlayer.start()
    }
    private fun playSpecialSound3() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_especial) // Reemplaza "sonido_especial" con el nombre correcto de tu archivo de sonido
        mediaPlayer.start()
    }
    private fun playSpecialSound4() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_especial4) // Reemplaza "sonido_especial" con el nombre correcto de tu archivo de sonido
        mediaPlayer.start()
    }
    private fun playSpecialSound5() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_especial5) // Reemplaza "sonido_especial" con el nombre correcto de tu archivo de sonido
        mediaPlayer.start()
    }
    private fun playSpecialSound6() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_especial6) // Reemplaza "sonido_especial" con el nombre correcto de tu archivo de sonido
        mediaPlayer.start()
    }
    private fun playSpecialSound7() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_especial7) // Reemplaza "sonido_especial" con el nombre correcto de tu archivo de sonido
        mediaPlayer.start()
    }
    private fun playSpecialSound8() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_especial8) // Reemplaza "sonido_especial" con el nombre correcto de tu archivo de sonido
        mediaPlayer.start()
    }

    private fun allCardsMatched(): Boolean {
        return imageViews.none { it.isEnabled }
    }

    private fun onGameWon() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.sonido_victoria)
        mediaPlayer.start()

        timer.cancel()
        Toast.makeText(this, "Felicidades! Tu puntaje fue: $score", Toast.LENGTH_LONG).show()

        val playerName = intent.getStringExtra("PLAYER_NAME")

        savePlayerScore(playerName, score)
        val lastScore = getPlayerLastScore(playerName)


    }
    private fun savePlayerScore(playerName: String?, score: Int) {
        playerName?.let {
            val databaseHandler = DatabaseHandler(this)
            databaseHandler.addPlayer(playerName)
            databaseHandler.updatePlayerScore(playerName, score)
        }
    }

    private fun getPlayerLastScore(playerName: String?): Int {
        var lastScore = 0
        playerName?.let {
            val databaseHandler = DatabaseHandler(this)
            lastScore = databaseHandler.getLastScore(playerName)
        }
        return lastScore
    }

    private fun updatePlayerScore(playerName: String?, newScore: Int) {
        playerName?.let {
            val databaseHandler = DatabaseHandler(this)
            val currentScore = databaseHandler.getLastScore(playerName)

            if (newScore > currentScore) {
                val db = databaseHandler.writableDatabase
                val values = ContentValues().apply {
                    put(DatabaseHandler.KEY_LAST_SCORE, newScore)
                }

                db.update(
                    DatabaseHandler.TABLE_NAME,
                    values,
                    "${DatabaseHandler.KEY_NAME} = ?",
                    arrayOf(playerName)
                )
                db.close()
            }
        }
    }


    private fun playMatchSound() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.coincidencia)
        mediaPlayer.start()
    }



    private fun resetGame() {

        score = 0
        updateScoreDisplay()
        selectedCard = null
        selectedImageRes = null
        imageViews.forEach {
            it.setImageResource(R.drawable.imagen9)
            it.isEnabled = true
        }
        timer.cancel()
        timeLeftInMillis = 60000
        startTimer()
    }

    private fun startTimer() {
        timer = object : CountDownTimer(timeLeftInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeftInMillis = millisUntilFinished
                updateCountDownText()
            }

            override fun onFinish() {
                onGameOver()
            }
        }.start()
    }

    private fun updateCountDownText() {
        val minutes = (timeLeftInMillis / 1000) / 60
        val seconds = (timeLeftInMillis / 1000) % 60
        val timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
        findViewById<TextView>(R.id.tvTimer).text = timeFormatted
    }

    private fun updateScoreDisplay() {
        findViewById<TextView>(R.id.tvScore).text = "Score: $score"
    }

    private fun onGameOver() {
        imageViews.forEach { it.isEnabled = false }
        Toast.makeText(this, "Game Over! Your score is: $score", Toast.LENGTH_LONG).show()

        timer.cancel()


    }


}
