package com.example.memorygame

import db.juegodememoria.DatabaseHandler
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.example.memorygame.R

class MainActivity : AppCompatActivity() {
    private lateinit var databaseHandler: DatabaseHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        databaseHandler = DatabaseHandler(this)

        val btnPlayGame: Button = findViewById(R.id.btnPlayGame)
        val etPlayerName: EditText = findViewById(R.id.etPlayerName)

        btnPlayGame.setOnClickListener {

            val playerName = etPlayerName.text.toString()


            databaseHandler.addPlayer(playerName)


            gameInit(playerName)
        }
    }

    private fun gameInit(playerName: String){

        val lastScore = databaseHandler.getLastScore(playerName)

        // Pasar el nombre del jugador y el último puntaje a la siguiente actividad
        val intent = Intent(this, MainActivi2::class.java).apply {
            putExtra("PLAYER_NAME", playerName)
            putExtra("LAST_SCORE", lastScore)
        }
        startActivity(intent)
    }

}
