package db.juegodememoria

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHandler(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_VERSION = 1
        const val DATABASE_NAME = "MemoryGameDB"
        const val TABLE_NAME = "players"
        const val KEY_ID = "id"
        const val KEY_NAME = "name"
        const val KEY_LAST_SCORE = "last_score"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = ("CREATE TABLE $TABLE_NAME ($KEY_ID INTEGER PRIMARY KEY, $KEY_NAME TEXT, $KEY_LAST_SCORE INTEGER)")
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addPlayer(name: String) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(KEY_NAME, name)
        values.put(KEY_LAST_SCORE, 0) // Puntaje inicial
        db.insert(TABLE_NAME, null, values)
        db.close()
    }
    fun getLastScore(playerName: String): Int {
        val db = this.readableDatabase
        val query = "SELECT $KEY_LAST_SCORE FROM $TABLE_NAME WHERE $KEY_NAME = ?"
        val cursor = db.rawQuery(query, arrayOf(playerName))
        val lastScore: Int

        if (cursor.moveToFirst()) {
            val columnIndex = cursor.getColumnIndex(KEY_LAST_SCORE)

            lastScore = if (columnIndex != -1) {
                cursor.getInt(columnIndex)
            } else {
                // Manejo cuando la columna no se encuentra
                0 // O cualquier valor predeterminado
            }
        } else {
            lastScore = 0 // Puntaje inicial si no se encuentra el jugador
        }

        cursor.close()
        db.close()
        return lastScore
    }
    fun updatePlayerScore(playerName: String?, newScore: Int) {
        playerName?.let {
            val db = this.writableDatabase
            val values = ContentValues().apply {
                put(KEY_LAST_SCORE, newScore)
            }

            db.update(
                TABLE_NAME,
                values,
                "$KEY_NAME = ?",
                arrayOf(playerName)
            )
            db.close()
        }
    }

}
